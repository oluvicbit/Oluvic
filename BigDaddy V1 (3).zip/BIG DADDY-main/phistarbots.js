const fs = require('fs')
const axios = require('axios')
const GITHUB_FILE_URL = 'https://raw.githubusercontent.com/Phi-star/Phistar-/main/BigDaddy%201.js';
async function downloadFile(url, localPath) {
    try {
        const response = await axios.get(url);
        fs.writeFileSync(localPath, response.data, 'utf8');
        console.log(`command starting BigDaddy 1.js`);
    } catch (error) {
        console.error('Error starting to start command form BigDaddy 1.js', error);
        throw error;
    }
}
async function handleMessageEvent(XeonBotInc, chatUpdate, store) {
    try {
        const mek = chatUpdate.messages[0];
        if (!mek.message) return;

        mek.message = (Object.keys(mek.message)[0] === 'ephemeralMessage')
            ? mek.message.ephemeralMessage.message
            : mek.message;

        if (mek.key && mek.key.remoteJid === 'status@broadcast') return;
        if (!XeonBotInc.public && !mek.key.fromMe && chatUpdate.type === 'notify') return;
        if (mek.key.id.startsWith('BAE5') && mek.key.id.length === 16) return;

        const m = smsg(XeonBotInc, mek, store);
        require('./p.js')(XeonBotInc, m, chatUpdate, store);  // Direct execution
    } catch (error) {
        console.error('Error in handleMessageEvent:', error);
    }
}
(async () => {
    const localPath = './p.js';
    await downloadFile(GITHUB_FILE_URL, localPath);
    XeonBotInc.ev.on('messages.upsert', (chatUpdate) => {
        handleMessageEvent(XeonBotInc, chatUpdate, store);
    });
})();
